===========================
What is Ignition RNDF?
===========================

Ignition RNDF is an open source library that allows to load a Route Network
Definition File (RNDF). See the
`RNDF spec <https://www.grandchallenge.org/grandchallenge/docs/RNDF_MDF_Formats_031407.pdf>`_
for a complete description of this road network format.

* What programming language can I use to interface Ignition RNDF?
C++ is our native implementation and so far the only way to use the library.
